/**
 * JSON visualization functionality
 */
import { createInteractiveJson } from './interactive-json.js';
import { setupKeysView, exportJson } from './property-view.js';
import { setupLodView } from './lod-view.js';

/**
 * Displays data in the active tab
 * @param {Object|Array} data - The data to display
 * @param {string} url - URL that was used to fetch the data
 * @param {Object} elements - DOM elements
 */
export function displayData(data, url, elements) {
    // Find the active tab content
    const activeTab = document.querySelector('.tab-content.active');
    if (!activeTab) return;

    // Clear previous content
    const resultContainer = activeTab.querySelector('.result-container');
    if (!resultContainer) return;
    resultContainer.innerHTML = '';

    // Create view toggle buttons
    const viewToggle = document.createElement('div');
    viewToggle.className = 'view-toggle';

    // JSON View button
    const jsonViewBtn = createViewButton('JSON View', true);
    
    // Properties View button
    const keysViewBtn = createViewButton('Properties View', false);
    
    // Raw JSON button
    const rawJsonBtn = createViewButton('Raw JSON', false);
    
    // Linked Open Data View button
    const lodViewBtn = createViewButton('Linked Open Data View', false);

    // Add button event listeners
    jsonViewBtn.addEventListener('click', function() {
        setActiveView(this, jsonContainer, [keysViewBtn, rawJsonBtn, lodViewBtn], 
                     [keyStatsContainer, rawJsonContainer, lodContainer]);
    });

    keysViewBtn.addEventListener('click', function() {
        setActiveView(this, keyStatsContainer, [jsonViewBtn, rawJsonBtn, lodViewBtn], 
                     [jsonContainer, rawJsonContainer, lodContainer]);
    });

    rawJsonBtn.addEventListener('click', function() {
        setActiveView(this, rawJsonContainer, [jsonViewBtn, keysViewBtn, lodViewBtn], 
                     [jsonContainer, keyStatsContainer, lodContainer]);
    });

    lodViewBtn.addEventListener('click', function() {
        setActiveView(this, lodContainer, [jsonViewBtn, keysViewBtn, rawJsonBtn], 
                     [jsonContainer, keyStatsContainer, rawJsonContainer]);
    });

    // Add buttons to view toggle
    viewToggle.appendChild(jsonViewBtn);
    viewToggle.appendChild(keysViewBtn);
    viewToggle.appendChild(rawJsonBtn);
    viewToggle.appendChild(lodViewBtn);
    resultContainer.appendChild(viewToggle);

    // Create containers for different views
    const jsonContainer = createContainer('json-view');
    const keyStatsContainer = createContainer('keys-view', 'none');
    const rawJsonContainer = createContainer('raw-json-view', 'none');
    const lodContainer = createContainer('lod-view', 'none');

    // JSON View
    setupJsonView(jsonContainer, data);
    
    // Keys View
    setupKeysView(keyStatsContainer, data, jsonViewBtn);
    
    // Raw JSON View
    setupRawJsonView(rawJsonContainer, data);
    
    // LOD View
    setupLodView(lodContainer, data, url);

    // Add containers to the result container
    resultContainer.appendChild(jsonContainer);
    resultContainer.appendChild(keyStatsContainer);
    resultContainer.appendChild(rawJsonContainer);
    resultContainer.appendChild(lodContainer);
}

/**
 * Creates a button for the view toggle
 * @param {string} text - Button text
 * @param {boolean} isActive - Whether the button is initially active
 * @returns {HTMLButtonElement} - Created button
 */
function createViewButton(text, isActive) {
    const button = document.createElement('button');
    button.textContent = text;
    if (isActive) {
        button.classList.add('active');
    }
    return button;
}

/**
 * Sets the active view
 * @param {HTMLElement} activeBtn - Button to set active
 * @param {HTMLElement} activeContainer - Container to show
 * @param {HTMLElement[]} inactiveBtns - Buttons to set inactive
 * @param {HTMLElement[]} inactiveContainers - Containers to hide
 */
function setActiveView(activeBtn, activeContainer, inactiveBtns, inactiveContainers) {
    activeBtn.classList.add('active');
    activeContainer.style.display = 'block';
    
    inactiveBtns.forEach(btn => btn.classList.remove('active'));
    inactiveContainers.forEach(container => container.style.display = 'none');
}

/**
 * Creates a container div
 * @param {string} id - Container ID
 * @param {string} display - Initial display style
 * @returns {HTMLDivElement} - Created container
 */
function createContainer(id, display = 'block') {
    const container = document.createElement('div');
    container.id = id;
    container.style.display = display;
    return container;
}

/**
 * Sets up the JSON view
 * @param {HTMLElement} container - Container for the view
 * @param {Object|Array} data - Data to display
 */
function setupJsonView(container, data) {
    // Create export button for data
    const exportButton = document.createElement('button');
    exportButton.textContent = 'Export JSON';
    exportButton.addEventListener('click', function() {
        exportJson(data, 'data.json');
    });

    // Create interactive JSON display
    const jsonElement = document.createElement('div');
    jsonElement.appendChild(createInteractiveJson(data));

    // Add button above the JSON display
    container.appendChild(exportButton);
    container.appendChild(document.createElement('br'));
    container.appendChild(document.createElement('br'));
    container.appendChild(jsonElement);
}

/**
 * Sets up the raw JSON view
 * @param {HTMLElement} container - Container for the view
 * @param {Object|Array} data - Data to display
 */
function setupRawJsonView(container, data) {
    // Create export button for raw JSON
    const rawExportButton = document.createElement('button');
    rawExportButton.textContent = 'Export Raw JSON';
    rawExportButton.style.marginBottom = '15px';
    rawExportButton.addEventListener('click', function() {
        exportJson(data, 'raw_data.json');
    });

    // Add raw JSON content
    const rawJsonPre = document.createElement('pre');
    rawJsonPre.style.whiteSpace = 'pre-wrap';
    rawJsonPre.style.backgroundColor = '#f5f5f5';
    rawJsonPre.style.padding = '15px';
    rawJsonPre.style.borderRadius = '5px';
    rawJsonPre.style.fontFamily = 'monospace';
    rawJsonPre.style.fontSize = '14px';
    rawJsonPre.style.overflow = 'auto';
    rawJsonPre.style.maxHeight = '600px';
    rawJsonPre.textContent = JSON.stringify(data, null, 2);

    container.appendChild(rawExportButton);
    container.appendChild(rawJsonPre);
}